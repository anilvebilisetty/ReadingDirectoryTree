﻿using System;

namespace FileReading
{
    class Program
    {
        static void Main(string[] args)
        {
            ReadFiles readFiles = new ReadFiles();
            readFiles.FetchParentDirectories();
        }
    }
}
