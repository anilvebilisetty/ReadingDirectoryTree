﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;

namespace FileReading
{
    public class ReadFiles
    {
       public void  FetchParentDirectories()
        {
            string containerPath = @"C:\Users\avebilisetty\Pictures\container";
            List<string> parentPaths = new List<string>();
            List<string> filePaths = Directory.GetFiles(containerPath, "*.xlsx", SearchOption.AllDirectories).ToList();
            filePaths.ForEach((filePath) =>
            {
                string parent = Directory.GetParent(filePath).FullName;
                if(!parentPaths.Contains(parent))
                {
                    parentPaths.Add(parent);
                }
            });
            CombineFiles(parentPaths);
            Console.ReadLine();
        }

        private void CombineFiles(List<string> parentDirectories)
        {
            parentDirectories.ForEach((folder) =>
            {
                DataTable dt = new DataTable();
                Directory.GetFiles(folder).ToList().ForEach((file) =>
                {
                    dt.Merge(ConvertToDataTable(file));
                }
                );
            });
        }

        private System.Data.DataTable ConvertToDataTable(string path)

        {

            System.Data.DataTable dt = null;

            try

            {

                object rowIndex = 1;

                dt = new System.Data.DataTable();

                DataRow row;

                Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();

                Microsoft.Office.Interop.Excel.Workbook workBook = app.Workbooks.Open(path, 0, true, 5, "", "", true,

                    Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "\t", false, false, 0, true, 1, 0);

                Microsoft.Office.Interop.Excel.Worksheet workSheet = (Microsoft.Office.Interop.Excel.Worksheet)workBook.ActiveSheet;

                int temp = 1;

                while (((Microsoft.Office.Interop.Excel.Range)workSheet.Cells[rowIndex, temp]).Value2 != null)

                {

                    dt.Columns.Add(Convert.ToString(((Microsoft.Office.Interop.Excel.Range)workSheet.Cells[rowIndex, temp]).Value2));

                    temp++;

                }

                rowIndex = Convert.ToInt32(rowIndex) + 1;

                int columnCount = temp;

                temp = 1;

                while (((Microsoft.Office.Interop.Excel.Range)workSheet.Cells[rowIndex, temp]).Value2 != null)

                {

                    row = dt.NewRow();

                    for (int i = 1; i < columnCount; i++)

                    {

                        row[i - 1] = Convert.ToString(((Microsoft.Office.Interop.Excel.Range)workSheet.Cells[rowIndex, i]).Value2);

                    }

                    dt.Rows.Add(row);

                    rowIndex = Convert.ToInt32(rowIndex) + 1;

                    temp = 1;

                }

                app.Workbooks.Close();

            }

            catch (Exception ex)

            {

                //lblError.Text = ex.Message;

            }

            return dt;

        }

    }
}
